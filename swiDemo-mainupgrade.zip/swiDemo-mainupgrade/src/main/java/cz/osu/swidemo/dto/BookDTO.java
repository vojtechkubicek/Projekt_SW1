package cz.osu.swidemo.dto;

public class BookDTO {
    private Long id;
    private String title;
    private String author; // Tady držíme textový formát pro React
    private int publishYear;

    public BookDTO() {} // Prázdný konstruktor pro Spring

    public BookDTO(Long id, String title, String author, int publishYear) {
        this.id = id;
        this.title = title;
        this.author = author;
        this.publishYear = publishYear;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public String getAuthor() { return author; }
    public void setAuthor(String author) { this.author = author; }
    public int getPublishYear() { return publishYear; }
    public void setPublishYear(int publishYear) { this.publishYear = publishYear; }
}
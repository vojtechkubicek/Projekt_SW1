package cz.osu.swidemo.entities;

import jakarta.persistence.*;
import java.util.List;

@Entity
@Table(name = "book") // Odkaz na vaši tabulku
public class Book {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String title;

    @Column(name = "publish_year") // Obvykle se to v DB jmenuje s podtržítkem
    private int publishYear;

    // TADY JE TA MAGIE: Propojení s tabulkou autorů přes vaši tabulku book_author
    @ManyToMany
    @JoinTable(
            name = "book_author",
            joinColumns = @JoinColumn(name = "book_id"),
            inverseJoinColumns = @JoinColumn(name = "author_id")
    )
    private List<Author> authors;

    public Book() {}

    public Book(String title, int publishYear) {
        this.title = title;
        this.publishYear = publishYear;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public int getPublishYear() { return publishYear; }
    public void setPublishYear(int publishYear) { this.publishYear = publishYear; }
    public List<Author> getAuthors() { return authors; }
    public void setAuthors(List<Author> authors) { this.authors = authors; }
}
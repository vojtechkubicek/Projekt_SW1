package cz.osu.swidemo.controllers;

import cz.osu.swidemo.dto.BookDTO;
import cz.osu.swidemo.entities.Author;
import cz.osu.swidemo.entities.Book;
import cz.osu.swidemo.repositories.AuthorRepository;
import cz.osu.swidemo.repositories.BookRepository;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/api/books")
@CrossOrigin
public class BookController {

    private final BookRepository bookRepository;
    private final AuthorRepository authorRepository;

    public BookController(BookRepository bookRepository, AuthorRepository authorRepository) {
        this.bookRepository = bookRepository;
        this.authorRepository = authorRepository;
    }

    // 1. Získáme knihy z DB a převedeme je pro React (do BookDTO)
    @GetMapping
    public List<BookDTO> getAllBooks() {
        List<BookDTO> result = new ArrayList<>();
        for (Book book : bookRepository.findAll()) {
            String authorName = "";
            // Pokud má kniha autora, vezmeme toho prvního
            if (book.getAuthors() != null && !book.getAuthors().isEmpty()) {
                authorName = book.getAuthors().get(0).getName();
            }
            result.add(new BookDTO(book.getId(), book.getTitle(), authorName, book.getPublishYear()));
        }
        return result;
    }

    // 2. React pošle BookDTO (s textem autora), my ho rozdělíme do dvou tabulek
    @PostMapping
    public BookDTO addBook(@RequestBody BookDTO newBookDTO) {
        // Najdeme autora v tabulce podle jména, nebo vytvoříme nového
        Author author = authorRepository.findByName(newBookDTO.getAuthor());
        if (author == null) {
            author = new Author(newBookDTO.getAuthor());
            author = authorRepository.save(author); // Uložíme nového autora do databáze
        }

        // Vytvoříme knihu
        Book book = new Book(newBookDTO.getTitle(), newBookDTO.getPublishYear());
        book.setAuthors(List.of(author)); // Propojíme knihu s autorem
        book = bookRepository.save(book); // Uložíme knihu

        // Vrátíme Reactu uložená data ve správném formátu
        return new BookDTO(book.getId(), book.getTitle(), author.getName(), book.getPublishYear());
    }

    @DeleteMapping("/{id}")
    public void deleteBook(@PathVariable Long id) {
        bookRepository.deleteById(id);
    }
}
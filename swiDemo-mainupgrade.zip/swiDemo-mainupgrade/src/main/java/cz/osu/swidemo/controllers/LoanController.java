package cz.osu.swidemo.controllers;

import cz.osu.swidemo.entities.Book;
import cz.osu.swidemo.entities.Loan;
import cz.osu.swidemo.entities.User;
import cz.osu.swidemo.repositories.BookRepository;
import cz.osu.swidemo.repositories.LoanRepository;
import cz.osu.swidemo.repositories.UserRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.security.Principal;
import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/api/loans")
@CrossOrigin(origins = "http://localhost:3000") // Lepší specifikovat původ kvůli CORS
public class LoanController {

    private final LoanRepository loanRepository;
    private final BookRepository bookRepository;
    private final UserRepository userRepository;

    public LoanController(LoanRepository loanRepository, BookRepository bookRepository, UserRepository userRepository) {
        this.loanRepository = loanRepository;
        this.bookRepository = bookRepository;
        this.userRepository = userRepository;
    }

    @PostMapping("/{bookId}")
    public String loanBook(@PathVariable Long bookId, Principal principal) {
        User user = userRepository.findByUsername(principal.getName());
        Book book = bookRepository.findById(bookId).orElseThrow();

        Loan loan = new Loan(user, book, LocalDate.now());
        loanRepository.save(loan);

        return "Kniha '" + book.getTitle() + "' byla úspěšně vypůjčena uživateli " + user.getUsername();
    }

    @GetMapping("/my-loans")
    public List<Loan> getMyLoans(java.security.Principal principal) {
        return loanRepository.findByUserUsername(principal.getName());
    }

    // --- PŘIDANÁ METODA PRO VRÁCENÍ KNIHY ---
    @DeleteMapping("/{id}")
    public ResponseEntity<?> returnBook(@PathVariable Long id, Principal principal) {
        // Najdeme výpůjčku podle ID
        return loanRepository.findById(id).map(loan -> {
            // Kontrola: Jen uživatel, který si knihu půjčil (nebo admin), ji může vrátit
            if (loan.getUser().getUsername().equals(principal.getName()) || principal.getName().equals("admin")) {
                loanRepository.delete(loan); // Smažeme záznam z databáze
                return ResponseEntity.ok().body("Kniha byla úspěšně vrácena.");
            } else {
                return ResponseEntity.status(403).body("Nemáte oprávnění vrátit cizí výpůjčku.");
            }
        }).orElse(ResponseEntity.notFound().build());
    }
}
package cz.osu.swidemo.entities;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;
import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name = "users")
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    @Column(name = "id", columnDefinition = "VARCHAR(36)")
    private String id;

    private String username;
    private String firstName;
    private String lastName;
    private String email;

    // N:1 - Mnoho uživatelů patří do jednoho oddělení
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "department_id")
    @JsonIgnoreProperties("users")
    private Department department;

    // M:N - Mnoho uživatelů má mnoho rolí
    @ManyToMany(fetch = FetchType.LAZY, cascade = {CascadeType.PERSIST, CascadeType.MERGE})
    @JoinTable(
            name = "user_roles",
            joinColumns = @JoinColumn(name = "user_id"),
            inverseJoinColumns = @JoinColumn(name = "role_id")
    )
    @JsonIgnoreProperties("users")
    private Set<Role> roles = new HashSet<>();

    public User() {}

    // Pomocné metody
    public void addRole(Role role) {
        this.roles.add(role);
        role.getUsers().add(this);
    }

    // Getters a Setters
    public String getId() { return id; }
    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }
    public String getFirstName() { return firstName; }
    public void setFirstName(String f) { this.firstName = f; }
    public String getLastName() { return lastName; }
    public void setLastName(String l) { this.lastName = l; }
    public String getEmail() { return email; }
    public void setEmail(String e) { this.email = e; }
    public Department getDepartment() { return department; }
    public void setDepartment(Department d) { this.department = d; }
    public Set<Role> getRoles() { return roles; }
    public void setRoles(Set<Role> r) { this.roles = r; }
}
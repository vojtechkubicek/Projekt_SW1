package cz.osu.swidemo.controllers;
import cz.osu.swidemo.repositories.DepartmentRepository;
import cz.osu.swidemo.entities.*;
import cz.osu.swidemo.repositories.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.UUID;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api/test")
public class TestController {

    @Autowired private UserRepository userRepository;
    @Autowired private DepartmentRepository departmentRepository;

    @GetMapping("/generate")
    public String generate() {
        // Vytvoříme oddělení (1:M)
        Department dep = new Department("Vývojové oddělení");
        departmentRepository.save(dep);

        // Vytvoříme roli (M:N)
        Role role = new Role("DEVELOPER");

        User user = new User();
        user.setUsername("dev-" + UUID.randomUUID().toString().substring(0,4));
        user.setFirstName("Petr");
        user.setLastName("Tester");
        user.setEmail("petr@osu.cz");
        user.setDepartment(dep); // Nastavení 1:M
        user.addRole(role);      // Nastavení M:N

        userRepository.save(user);
        return "Data vygenerována!";
    }

    @GetMapping("/users")
    public List<User> getAllUsers() {
        return userRepository.findAll();
    }
}
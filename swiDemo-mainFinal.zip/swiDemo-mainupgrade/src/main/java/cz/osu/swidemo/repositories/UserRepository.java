package cz.osu.swidemo.repositories;

import cz.osu.swidemo.entities.User;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

public interface UserRepository extends JpaRepository<User, String> {

    // Tahle metoda je klíčová pro přihlašování.
    // Spring díky ní dokáže najít uživatele v DB podle login jména.
    Optional<User> findByUsername(String username);
}